#include "User.h"
#include <string>
using namespace std;

User::User( string _login, string _password ){
	login = _login;
	password = _password; }

bool User::ver(string _login, string _password) {
	bool aux = false;
	if ((login == _login) && (password == _password)) aux = true;
	return aux;

}