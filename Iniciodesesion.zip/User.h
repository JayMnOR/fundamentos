#pragma once
#include <string>
using namespace std;

class User
{
private:
	string login;
	string password;
public:
	User(string _login, string _password);
	bool ver(string _login, string _password);
};

