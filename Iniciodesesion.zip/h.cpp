#include <iostream>
#include "User.h"
using namespace std;

int main()
{
	string user,  pass;
	User user1("usuario", "12345");
	cout << "ingresar usuario: ";
	cin >> user;
	cout << "Ingresar password: ";
	cin >> pass;

	if (user1.ver(user, pass)) { cout << "Adelante" << endl; }
	else cout << "Error"<<endl;
	return 0;
}
