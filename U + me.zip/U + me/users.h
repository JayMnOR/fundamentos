#pragma once
#ifndef USERS_H 
#define USERS_H
#include <string>
using namespace std;
class Users
{
private:
	string login;
	string password;
public:
	Users(string _login, string _password);
	bool verificarlogin(string _login, string _password);
};
#endif // USERS_H


//nice to meet you