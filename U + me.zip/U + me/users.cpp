#include "users.h"
#include <string>
using namespace std;
Users::Users(string _login, string _password)
{
	login = _login;
	password = _password;
}

bool Users::verificarlogin(string _login, string _password)
{
	if ((login == _login) && (password == _password))
		return true;
	return false;
}


